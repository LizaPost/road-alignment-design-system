/* --------------------------------------------------------------------------------
Configuration properties for road alignment generation;
Stores parameters for alignment generation and geometry calculations;
Values are loaded from application.properties and validated at startup.
--------------------------------------------------------------------------------  */

package geodesy.roadalignment.config;

import jakarta.validation.constraints.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Validated
@ConfigurationProperties(prefix = "road-alignment.alignment")
public record AlignmentProperties (

    @Positive(message = "Sample interval must be greater than zero")
    double sampleInterval,                                                  // distance between consecutive alignment sampling points

    @NotEmpty(message = "Alternative offsets must not be empty")
    List<Double> alternativeOffsets,                                        // lateral offsets to generate alternative alignment routes

    @Positive(message = "Same-point tolerance must be greater than zero")
    double samePointTolerance,                                             // tolerance for alignment points comparison

    @DecimalMin(value = "0.0", inclusive = false, message = "First control point fraction must be greater than zero")
    @DecimalMax(value = "1.0", inclusive = false, message = "First control point fraction must be less than one")
    double firstControlPointFraction,                                       // relative positions to define intermediate control points

    @DecimalMin(value = "0.0", inclusive = false, message = "Second control point fraction must be greater than zero")
    @DecimalMax(value = "1.0", inclusive = false, message = "Second control point fraction must be less than one")
    double secondControlPointFraction
) {

    // an immutable copy prevents external code from modifying values
    public AlignmentProperties {
        if (alternativeOffsets != null) {
            alternativeOffsets = Collections.unmodifiableList(new ArrayList<>(alternativeOffsets));
        }
    }

    // verifies that second control point is located after first one
    @AssertTrue(message = "Second control point fraction must be greater than first control point fraction")
    public boolean isControlPointFractionsValid() {
        return secondControlPointFraction > firstControlPointFraction;
    }
}


    /*// setters
    public void setSampleInterval(double sampleInterval) {
        this.sampleInterval = sampleInterval;
    }

    public void setAlternativeOffsets(List<Double> alternativeOffsets) {
        this.alternativeOffsets = List.copyOf(alternativeOffsets);
    }

    public void setSamePointTolerance(double samePointTolerance) {
        this.samePointTolerance = samePointTolerance;
    }

    public void setFirstControlPointFraction(double firstControlPointFraction) {
        this.firstControlPointFraction = firstControlPointFraction;
    }

    public void setSecondControlPointFraction(double secondControlPointFraction) {
        this.secondControlPointFraction = secondControlPointFraction;
    }

    // getters
    public double getSampleInterval() {
        return sampleInterval;
    }

    public List<Double> getAlternativeOffsets() {
        return alternativeOffsets;
    }

    public double getSamePointTolerance() {
        return samePointTolerance;
    }

    public double getFirstControlPointFraction() {
        return firstControlPointFraction;
    }

    public double getSecondControlPointFraction() {
        return secondControlPointFraction;
    }*/

