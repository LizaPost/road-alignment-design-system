/* --------------------------------------------------------------------------------
Represents a request to generate road alignment alternatives
--------------------------------------------------------------------------------  */

package geodesy.roadalignment.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record AlignmentRequest(

        @NotBlank
        String datasetId,

        @NotNull
        @Valid
        CoordinateRequest start,

        @NotNull
        @Valid
        CoordinateRequest end
) {
}
