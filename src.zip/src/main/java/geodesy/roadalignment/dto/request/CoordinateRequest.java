/* --------------------------------------------------------------------------------
Represents a two-dimensional coordinate received from frontend
(note) elevation is excluded here because it is calculated by backend
according to the selected terrain surface
--------------------------------------------------------------------------------  */

package geodesy.roadalignment.dto.request;

import jakarta.validation.constraints.AssertTrue;

public record CoordinateRequest(double x, double y) {

    @AssertTrue(message = "Coordinate values must be finite.")
    public boolean isCoordinateFinite() {

        return Double.isFinite(x) && Double.isFinite(y);
    }
}
