package geodesy.roadalignment.model;

import java.util.List;

public record Alignment(
        String id,
        List<AlignmentPoint> points,
        double length
) {
}
