package geodesy.roadalignment.model;

import java.util.List;

public record AlignmentAlternative(
        String id,
        List<AlignmentPoint> alignmentPoints,
        List<ProfilePoint> profile,
        double length,
        double maximumGrade,
        EarthworkResult earthwork,
        double roadWidth
) {
}
