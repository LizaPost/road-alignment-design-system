package geodesy.roadalignment.controller;

import geodesy.roadalignment.dto.request.AlignmentRequest;
import geodesy.roadalignment.model.*;
import geodesy.roadalignment.service.TerrainDataService;
import geodesy.roadalignment.service.AlignmentAnalysisService;
import geodesy.roadalignment.service.TinService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alignments")
public class AlignmentController {

    private final AlignmentAnalysisService analysisService;
    private final TerrainDataService terrainDataService;
    private final TinService tinService;

    public AlignmentController (AlignmentAnalysisService analysisService, TerrainDataService terrainDataService, TinService tinService) {
        this.analysisService = analysisService;
        this.terrainDataService = terrainDataService;
        this.tinService = tinService;
    }

    @PostMapping("/generate")
    public List<AlignmentAlternative> generateAlignments (@RequestBody AlignmentRequest request) {

        // always use currently active survey dataset
        List<Triangle> triangles = tinService.triangulate(terrainDataService.getPoints());

        return analysisService.analyze(request.start(), request.end(), triangles);
    }
}
