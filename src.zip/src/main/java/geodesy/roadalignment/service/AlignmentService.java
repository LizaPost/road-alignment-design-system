package geodesy.roadalignment.service;

import geodesy.roadalignment.model.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AlignmentService {

    private static final double SAMPLE_INTERVAL = 5.0;
    private final TerrainService terrainService;

    public AlignmentService (TerrainService terrainService) {
        this.terrainService = terrainService;
    }

    public Alignment createAlignment(String id, List<ProjectPoint> route, List<Triangle> triangles) {

        List<AlignmentPoint> points = new ArrayList<>();
        double station = 0.0;

        for (int i = 0; i < route.size() - 1; i++) {
            ProjectPoint start = route.get(i);
            ProjectPoint end = route.get(i + 1);

            double dx = end.x() - start.x();
            double dy = end.y() - start.y();

            double segmentLength = Math.sqrt(dx * dx + dy * dy);

            int sampleCount = Math.max(
                    1,
                    (int) Math.ceil(segmentLength / SAMPLE_INTERVAL)
            );

            System.out.printf(
                    "Route start: X=%.2f, Y=%.2f, Z=%.2f%n",
                    route.get(0).x(),
                    route.get(0).y(),
                    route.get(0).z()
            );

            // Skip the first sample of subsequent segments to avoid
            // adding the shared route vertex twice.
            int firstSample = (i == 0) ? 0 : 1;

            for (int j = firstSample; j <= sampleCount; j++) {
                double t = (double) j / sampleCount;

                double x = start.x() + t * dx;
                double y = start.y() + t * dy;

                // Station is measured from the start of the entire route.
                double pointStation = station + t * segmentLength;

                double terrainElevation =
                        terrainService.getElevation(x, y, triangles);

                points.add(new AlignmentPoint(
                        pointStation,
                        x,
                        y,
                        terrainElevation,
                        0.0
                ));
            }

            // Advance the starting station for the next route segment.
            station += segmentLength;
        }

        // add the final point
        ProjectPoint last = route.get(route.size() - 1);

        double terrainElevation = terrainService.getElevation(last.x(), last.y(), triangles);

        points.add(new AlignmentPoint(station, last.x(), last.y(), terrainElevation, 0));

        // Verify stationing against cumulative horizontal distance.
        double cumulativeDistance = 0.0;

        System.out.println("\n--- Stationing Verification ---");

        for (int i = 0; i < points.size(); i++) {
            AlignmentPoint point = points.get(i);

            if (i > 0) {
                AlignmentPoint previous = points.get(i - 1);

                double dx = point.x() - previous.x();
                double dy = point.y() - previous.y();

                cumulativeDistance += Math.sqrt(dx * dx + dy * dy);
            }

            double difference = point.station() - cumulativeDistance;

            System.out.printf(
                    "Point %d | Station: %.3f | Cumulative distance: %.3f"
                            + " | Difference: %.6f%n",
                    i,
                    point.station(),
                    cumulativeDistance,
                    difference
            );
        }

        System.out.printf("Alignment length: %.3f%n", station);
        System.out.printf("Final point station: %.3f%n", points.getLast().station());
        System.out.printf("Calculated total distance: %.3f%n", cumulativeDistance);
        System.out.println("--- End Verification ---\n");

        return new Alignment(id, points, station);
    }

    public Alignment applyDesignProfile(Alignment alignment, List<ProfilePoint> profile) {

        List<AlignmentPoint> updatedPoints = new ArrayList<>();

        for (int i = 0; i < alignment.points().size(); i++) {
            AlignmentPoint original = alignment.points().get(i);
            ProfilePoint profilePoint = profile.get(i);

            updatedPoints.add(new AlignmentPoint(
                                                original.station(),
                                                original.x(),
                                                original.y(),
                                                original.terrainElevation(),
                                                profilePoint.designElevation()
            ));
        }
        return new Alignment(alignment.id(), updatedPoints, alignment.length());
    }
}
