/*
 * ------------------------------------------------------------------------------------------
 * File: AlignmentGeneratorService.java
 *
 * Purpose:
 * Generates alternative road routes between two user-selected points.
 *
 * Description:
 * Builds a regular grid over the available TIN terrain surface, connects
 * neighboring grid nodes into a graph, and searches for alternative routes
 * using the A* algorithm.
 *
 * Route costs depend on horizontal distance and existing terrain slope.
 * Previously used graph edges receive additional penalties to encourage
 * the discovery of different routes.
 *
 * Important:
 * This is an initial terrain-aware route-search algorithm. It does not yet
 * optimize the finished road's design profile or earthwork volumes.
 * Those calculations remain the responsibility of the analysis services.
 * ------------------------------------------------------------------------------------------
 */

package geodesy.roadalignment.service;

import geodesy.roadalignment.model.ProjectPoint;
import geodesy.roadalignment.model.TerrainPoint;
import geodesy.roadalignment.model.Triangle;
import org.springframework.stereotype.Service;

import java.util.*;

/*
 * ------------------------------------------------------------------------------------------
 * Purpose:
 *
 * Generates preliminary alternative road alignments over a triangulated terrain surface.
 *
 * Description:
 *
 * The service builds a regular grid over the TIN (Triangulated Irregular Network) and uses
 * A* search to find routes between the exact selected start and end coordinates.
 *
 * The route cost considers:
 * 1. Horizontal distance.
 * 2. Terrain slope between neighboring nodes.
 * 3. Terrain elevation above a reference elevation interpolated between the endpoints.
 * 4. Reuse of edges from previously generated routes.
 *
 * The grid spacing is selected automatically to respect the maximum grid-node limit.
 *
 * Important:
 *
 * These are preliminary terrain-aware paths, not finished engineering road designs.
 * The elevation reference is a heuristic. Road grades, vertical curves, and cut-and-fill
 * volumes must be calculated separately before evaluating engineering feasibility.
 * ------------------------------------------------------------------------------------------
 */
@Service
public class AlignmentGeneratorService {

    private final TerrainService terrainService;

    public AlignmentGeneratorService(TerrainService terrainService) {
        this.terrainService = terrainService;
    }

    /* -------------------------------- configuration ------------------------------------- */

    private static final double PREFERRED_GRID_SPACING = 2.5;

    private static final int MAX_GRID_NODES = 50_000;

    private static final int MAX_ALTERNATIVES = 5;

    private static final int MAX_ENDPOINT_CONNECTIONS = 8;

    private static final int MAX_SEARCH_ATTEMPTS = 15;

    private static final double SLOPE_WEIGHT = 75.0;

    private static final double ELEVATION_WEIGHT = 2.0;

    private static final double ELEVATION_SCALE = 5.0;

    private static final double REUSED_EDGE_PENALTY = 4.0;

    private static final double EPSILON = 1e-9;

    /* -------------------------------- main operation ------------------------------------ */

    public List<List<ProjectPoint>> generateAlternatives(
            ProjectPoint start,
            ProjectPoint end,
            List<Triangle> triangles) {

        validateInput(start, end, triangles);

        // Preserve the exact selected XY coordinates and interpolate their terrain elevations.
        ProjectPoint terrainStart = new ProjectPoint(
                start.x(),
                start.y(),
                terrainService.getElevation(start.x(), start.y(), triangles)
        );

        ProjectPoint terrainEnd = new ProjectPoint(
                end.x(),
                end.y(),
                terrainService.getElevation(end.x(), end.y(), triangles)
        );

        if (distance2D(terrainStart, terrainEnd) < EPSILON) {
            throw new IllegalArgumentException(
                    "The start and end points must be different."
            );
        }

        GridGraph graph = buildGrid(triangles, terrainStart, terrainEnd);

        if (graph.gridNodeCount == 0) {
            throw new IllegalArgumentException(
                    "No usable grid nodes could be generated inside the terrain."
            );
        }

        // Add virtual endpoint nodes only after recording the grid-node count.
        int startId = graph.addNode(terrainStart);
        int endId = graph.addNode(terrainEnd);

        connectEndpointToGrid(graph, startId);
        connectEndpointToGrid(graph, endId);

        // Permit a direct connection for nearby endpoints.
        if (distance2D(terrainStart, terrainEnd)
                <= graph.gridSpacing * 2.0) {
            graph.addUndirectedEdge(startId, endId);
        }

        List<List<ProjectPoint>> alternatives = new ArrayList<>();
        Set<String> signatures = new HashSet<>();
        Map<Long, Integer> edgeUsage = new HashMap<>();

        for (int attempt = 0;
             attempt < MAX_SEARCH_ATTEMPTS
                     && alternatives.size() < MAX_ALTERNATIVES;
             attempt++) {

            List<Integer> path = findPath(
                    graph,
                    startId,
                    endId,
                    terrainStart,
                    terrainEnd,
                    edgeUsage
            );

            if (path.isEmpty()) {
                break;
            }

            List<ProjectPoint> route = simplifyPath(
                    convertPathToPoints(graph, path, terrainStart, terrainEnd)
            );

            // Avoid returning the same route more than once.
            signatures.add(createRouteSignature(route));

            if (alternatives.stream().noneMatch(
                    existing -> createRouteSignature(existing)
                            .equals(createRouteSignature(route)))) {
                alternatives.add(route);
            }

            // Penalize edges from every attempted path to encourage exploration.
            for (int i = 0; i < path.size() - 1; i++) {
                long key = edgeKey(path.get(i), path.get(i + 1));
                edgeUsage.merge(key, 1, Integer::sum);
            }
        }

        return alternatives;
    }

    /* -------------------------------- validation ---------------------------------------- */

    private void validateInput(
            ProjectPoint start,
            ProjectPoint end,
            List<Triangle> triangles) {

        if (start == null || end == null) {
            throw new IllegalArgumentException("Start and end points are required.");
        }

        if (!Double.isFinite(start.x()) || !Double.isFinite(start.y())
                || !Double.isFinite(end.x()) || !Double.isFinite(end.y())) {
            throw new IllegalArgumentException("Start and end coordinates must be finite.");
        }

        if (triangles == null || triangles.isEmpty()) {
            throw new IllegalArgumentException("Terrain triangles are required.");
        }
    }

    /* -------------------------------- grid creation ------------------------------------- */

    private GridGraph buildGrid(
            List<Triangle> triangles,
            ProjectPoint start,
            ProjectPoint end) {

        double minX = Double.POSITIVE_INFINITY;
        double minY = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY;
        double maxY = Double.NEGATIVE_INFINITY;

        // Find the bounding rectangle of the terrain TIN.
        for (Triangle triangle : triangles) {
            TerrainPoint[] vertices = {
                    triangle.a(),
                    triangle.b(),
                    triangle.c()
            };

            for (TerrainPoint point : vertices) {
                minX = Math.min(minX, point.x());
                minY = Math.min(minY, point.y());
                maxX = Math.max(maxX, point.x());
                maxY = Math.max(maxY, point.y());
            }
        }

        double gridSpacing = chooseGridSpacing(
                maxX - minX,
                maxY - minY
        );

        int columns = (int) Math.floor((maxX - minX) / gridSpacing) + 1;
        int rows = (int) Math.floor((maxY - minY) / gridSpacing) + 1;

        System.out.printf(
                Locale.US,
                "Terrain grid: spacing = %.2f, columns = %d, rows = %d, potential nodes = %d%n",
                gridSpacing,
                columns,
                rows,
                (long) columns * rows
        );

        GridGraph graph = new GridGraph(gridSpacing);

        Map<String, Integer> nodeByGridPosition = new HashMap<>();

        // Add only nodes for which the TIN can provide an elevation.
        for (int row = 0; row < rows; row++) {
            double y = minY + row * gridSpacing;

            for (int column = 0; column < columns; column++) {
                double x = minX + column * gridSpacing;

                try {
                    double z = terrainService.getElevation(x, y, triangles);

                    int id = graph.addNode(new ProjectPoint(x, y, z));

                    graph.gridIds.add(id);
                    nodeByGridPosition.put(gridKey(column, row), id);

                } catch (IllegalArgumentException exception) {
                    // This location is outside the TIN or cannot be interpolated.
                }
            }
        }

        // Freeze the boundary between actual grid nodes and virtual endpoint nodes.
        graph.gridNodeCount = graph.nodes.size();

        // Connect the eight neighboring grid positions.
        int[][] directions = {
                {-1, -1}, {0, -1}, {1, -1},
                {-1,  0},           {1,  0},
                {-1,  1}, {0,  1}, {1,  1}
        };

        for (int id : graph.gridIds) {
            ProjectPoint point = graph.nodes.get(id);

            int column = (int) Math.round((point.x() - minX) / gridSpacing);
            int row = (int) Math.round((point.y() - minY) / gridSpacing);

            for (int[] direction : directions) {
                int neighborColumn = column + direction[0];
                int neighborRow = row + direction[1];

                Integer neighborId = nodeByGridPosition.get(
                        gridKey(neighborColumn, neighborRow)
                );

                if (neighborId != null && neighborId > id) {
                    graph.addUndirectedEdge(id, neighborId);
                }
            }
        }

        return graph;
    }

    /*
     * Choose the finest grid spacing that keeps the rectangular grid within the node limit.
     * Start at the preferred 2.5 m spacing and increase it gradually if needed.
     */
    private double chooseGridSpacing(double width, double height) {
        double spacing = PREFERRED_GRID_SPACING;

        while (true) {
            long columns = (long) Math.floor(width / spacing) + 1;
            long rows = (long) Math.floor(height / spacing) + 1;

            if (columns * rows <= MAX_GRID_NODES) {
                return spacing;
            }

            spacing *= 1.25;
        }
    }

    private String gridKey(int column, int row) {
        return column + "," + row;
    }

    /* ----------------------------- endpoint connections -------------------------------- */

    private void connectEndpointToGrid(GridGraph graph, int endpointId) {
        ProjectPoint endpoint = graph.nodes.get(endpointId);

        List<Integer> candidates = new ArrayList<>();

        // Search only actual grid nodes, never the other virtual endpoint.
        for (int id = 0; id < graph.gridNodeCount; id++) {
            ProjectPoint candidate = graph.nodes.get(id);

            if (distance2D(endpoint, candidate) <= graph.gridSpacing * 2.0) {
                candidates.add(id);
            }
        }

        candidates.sort(Comparator.comparingDouble(
                id -> distance2D(endpoint, graph.nodes.get(id))
        ));

        int limit = Math.min(MAX_ENDPOINT_CONNECTIONS, candidates.size());

        for (int i = 0; i < limit; i++) {
            graph.addUndirectedEdge(endpointId, candidates.get(i));
        }
    }

    /* -------------------------------- A* search ----------------------------------------- */

    private List<Integer> findPath(
            GridGraph graph,
            int startId,
            int endId,
            ProjectPoint start,
            ProjectPoint end,
            Map<Long, Integer> edgeUsage) {

        int nodeCount = graph.nodes.size();

        double[] costs = new double[nodeCount];
        int[] previous = new int[nodeCount];
        boolean[] visited = new boolean[nodeCount];

        Arrays.fill(costs, Double.POSITIVE_INFINITY);
        Arrays.fill(previous, -1);

        PriorityQueue<SearchState> open = new PriorityQueue<>(
                Comparator.comparingDouble(SearchState::estimatedTotalCost)
        );

        costs[startId] = 0.0;
        open.add(new SearchState(
                startId,
                heuristic(graph.nodes.get(startId), graph.nodes.get(endId))
        ));

        while (!open.isEmpty()) {
            SearchState state = open.poll();
            int currentId = state.nodeId();

            if (visited[currentId]) {
                continue;
            }

            if (currentId == endId) {
                return reconstructPath(previous, endId);
            }

            visited[currentId] = true;

            ProjectPoint current = graph.nodes.get(currentId);

            for (int neighborId : graph.adjacency.get(currentId)) {
                if (visited[neighborId]) {
                    continue;
                }

                ProjectPoint neighbor = graph.nodes.get(neighborId);

                double edgeCost = calculateEdgeCost(
                        current,
                        neighbor,
                        start,
                        end
                );

                int uses = edgeUsage.getOrDefault(
                        edgeKey(currentId, neighborId),
                        0
                );

                if (uses > 0) {
                    edgeCost *= Math.pow(REUSED_EDGE_PENALTY, uses);
                }

                double tentativeCost = costs[currentId] + edgeCost;

                if (tentativeCost < costs[neighborId]) {
                    costs[neighborId] = tentativeCost;
                    previous[neighborId] = currentId;

                    double estimatedTotal = tentativeCost
                            + heuristic(neighbor, graph.nodes.get(endId));

                    open.add(new SearchState(neighborId, estimatedTotal));
                }
            }
        }

        return Collections.emptyList();
    }

    /*
     * Edge cost combines horizontal distance, slope, and excess terrain elevation.
     * The elevation term penalizes terrain above the interpolated endpoint reference.
     */
    private double calculateEdgeCost(
            ProjectPoint a,
            ProjectPoint b,
            ProjectPoint start,
            ProjectPoint end) {

        double length = distance2D(a, b);

        if (length < EPSILON) {
            return 0.0;
        }

        double slope = Math.abs(b.z() - a.z()) / length;

        double referenceAverage = (
                referenceElevation(a, start, end)
                        + referenceElevation(b, start, end)
        ) / 2.0;

        double terrainAverage = (a.z() + b.z()) / 2.0;

        double excessElevation = Math.max(
                0.0,
                terrainAverage - referenceAverage
        );

        double normalizedExcess = excessElevation / ELEVATION_SCALE;

        double slopePenalty = SLOPE_WEIGHT * slope * slope;

        double elevationPenalty = ELEVATION_WEIGHT
                * normalizedExcess * normalizedExcess;

        return length * (1.0 + slopePenalty + elevationPenalty);
    }

    private double referenceElevation(
            ProjectPoint point,
            ProjectPoint start,
            ProjectPoint end) {

        double dx = end.x() - start.x();
        double dy = end.y() - start.y();

        double lengthSquared = dx * dx + dy * dy;

        if (lengthSquared < EPSILON) {
            return start.z();
        }

        double fraction = (
                (point.x() - start.x()) * dx
                        + (point.y() - start.y()) * dy
        ) / lengthSquared;

        fraction = Math.max(0.0, Math.min(1.0, fraction));

        return start.z() + fraction * (end.z() - start.z());
    }

    private double heuristic(ProjectPoint a, ProjectPoint b) {
        return distance2D(a, b);
    }

    /* -------------------------------- path utilities ------------------------------------ */

    private List<Integer> reconstructPath(int[] previous, int endId) {
        List<Integer> path = new ArrayList<>();
        int current = endId;

        while (current != -1) {
            path.add(current);
            current = previous[current];
        }

        Collections.reverse(path);
        return path;
    }

    private List<ProjectPoint> convertPathToPoints(
            GridGraph graph,
            List<Integer> path,
            ProjectPoint start,
            ProjectPoint end) {

        List<ProjectPoint> points = new ArrayList<>();
        points.add(start);

        for (int i = 1; i < path.size() - 1; i++) {
            points.add(graph.nodes.get(path.get(i)));
        }

        points.add(end);
        return points;
    }

    /*
     * Remove collinear intermediate points only when the route continues in the same direction.
     */
    private List<ProjectPoint> simplifyPath(List<ProjectPoint> points) {
        if (points.size() <= 2) {
            return points;
        }

        List<ProjectPoint> simplified = new ArrayList<>();
        simplified.add(points.getFirst());

        for (int i = 1; i < points.size() - 1; i++) {
            ProjectPoint previous = simplified.getLast();
            ProjectPoint current = points.get(i);
            ProjectPoint next = points.get(i + 1);

            double cross = (current.x() - previous.x())
                    * (next.y() - current.y())
                    - (current.y() - previous.y())
                    * (next.x() - current.x());

            double dot = (current.x() - previous.x())
                    * (next.x() - current.x())
                    + (current.y() - previous.y())
                    * (next.y() - current.y());

            if (Math.abs(cross) > EPSILON || dot < 0.0) {
                simplified.add(current);
            }
        }

        simplified.add(points.getLast());
        return simplified;
    }

    private String createRouteSignature(List<ProjectPoint> route) {
        StringBuilder signature = new StringBuilder();

        for (ProjectPoint point : route) {
            signature.append(Math.round(point.x() * 1000))
                    .append(',')
                    .append(Math.round(point.y() * 1000))
                    .append(';');
        }

        return signature.toString();
    }

    private double distance2D(ProjectPoint a, ProjectPoint b) {
        return Math.hypot(a.x() - b.x(), a.y() - b.y());
    }

    private long edgeKey(int a, int b) {
        int low = Math.min(a, b);
        int high = Math.max(a, b);

        return ((long) low << 32) | (high & 0xffffffffL);
    }

    /* -------------------------------- graph structures ---------------------------------- */

    private static class GridGraph {

        private final List<ProjectPoint> nodes = new ArrayList<>();
        private final List<Set<Integer>> adjacency = new ArrayList<>();
        private final List<Integer> gridIds = new ArrayList<>();

        private final double gridSpacing;

        private int gridNodeCount;

        private GridGraph(double gridSpacing) {
            this.gridSpacing = gridSpacing;
        }

        private int addNode(ProjectPoint point) {
            int id = nodes.size();

            nodes.add(point);
            adjacency.add(new HashSet<>());

            return id;
        }

        private void addUndirectedEdge(int a, int b) {
            if (a == b) {
                return;
            }

            adjacency.get(a).add(b);
            adjacency.get(b).add(a);
        }
    }

    private record SearchState(
            int nodeId,
            double estimatedTotalCost
    ) {
    }
}


/*
package geodesy.roadalignment.service;

import geodesy.roadalignment.model.ProjectPoint;
import geodesy.roadalignment.model.TerrainPoint;
import geodesy.roadalignment.model.Triangle;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AlignmentGeneratorService {

    private final TerrainService terrainService;

    public AlignmentGeneratorService(TerrainService terrainService) {
        this.terrainService = terrainService;
    }

    public List<List<ProjectPoint>> generateAlternatives(ProjectPoint start, ProjectPoint end, List<Triangle> triangles) {

        double dx = end.x() - start.x();
        double dy = end.y() - start.y();
        double straightDistance = Math.sqrt(dx * dx + dy * dy);

        if (straightDistance < 1e-9) {
            throw new IllegalArgumentException("Start and end points cannot be the same.");
        }

        // unit perpendicular vector
        double perpendicularX = -dy / straightDistance;
        double perpendicularY = dx / straightDistance;

        // candidates are a percentage of the straight-line start/end distance
        double[] offsets = {-0.25, -0.12, 0.0, 0.12, 0.25};

        List<List<ProjectPoint>> alternatives = new ArrayList<>();

        for (double offset : offsets) {
            double offsetDistance = straightDistance * offset;

            ProjectPoint control1 = createControlPoint (start, end, perpendicularX, perpendicularY, offsetDistance);
            ProjectPoint control2 = createControlPoint (start, end, perpendicularX, perpendicularY, offsetDistance);

            // move control points to different positions along the route
            control1 = moveAlongLine(start, end, control1, 0.33);
            control2 = moveAlongLine(start, end, control2, 0.66);

            List<ProjectPoint> route = List.of(start, control1, control2, end);

            if (isRouteInsideTerrain(route, triangles)) {
                System.out.println("Accepted alternative, offset: " + offset);
                alternatives.add(route);
            } else {
                System.out.println("Rejected alternative, offset: " + offset);
            }
        }
        return alternatives;
    }

    private ProjectPoint createControlPoint(ProjectPoint start, ProjectPoint end, double perpendicularX, double perpendicularY, double offset) {

        double middleX = (start.x() + end.x()) / 2.0;
        double middleY = (start.y() + end.y()) / 2.0;

        return new ProjectPoint(middleX + perpendicularX * offset, middleY + perpendicularY * offset, 0);
    }

    private ProjectPoint moveAlongLine(ProjectPoint start, ProjectPoint end, ProjectPoint point, double fraction) {

        double baseX = start.x() + (end.x() - start.x()) * fraction;
        double baseY = start.y() + (end.y() - start.y()) * fraction;

        double offsetX = point.x() - (start.x() + end.x()) / 2.0;
        double offsetY = point.y() - (start.y() + end.y()) / 2.0;

        return new ProjectPoint(baseX + offsetX, baseY + offsetY, 0);
    }

    private boolean isRouteInsideTerrain(List<ProjectPoint> route, List<Triangle> triangles) {

        try {
            for (ProjectPoint point : route) {
                terrainService.getElevation(point.x(), point.y(), triangles);
            }
            return true;
        } catch (IllegalArgumentException exception) {
            System.out.println("Route rejected: " + exception.getMessage());
            return false;
        }
    }
}
*/
